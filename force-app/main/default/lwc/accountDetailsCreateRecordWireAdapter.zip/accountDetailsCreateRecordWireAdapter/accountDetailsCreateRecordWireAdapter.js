import { LightningElement,wire } from 'lwc';
import getParentAccounts from '@salesforce/apex/AccountHelper.getParentAccounts';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import ACCOUNT_OBJECT from  "@salesforce/schema/Account";
import PARENT_ACCOUNT from "@salesforce/schema/Account.ParentId";
import ACCOUNT_NAME from "@salesforce/schema/Account.Name";
import SLAEXPDATE from "@salesforce/schema/Account.SLAExpirationDate__c";
import DESCRIPTION from "@salesforce/schema/Account.Description";
import NO_OF_LOCATIONS  from "@salesforce/schema/Account.NumberofLocations__c"
import SLA_TYPE  from "@salesforce/schema/Account.SLA__c"
import { createRecord } from 'lightning/uiRecordApi';

export default class AccountDetailsCreateRecordWireAdapter extends LightningElement {


    parentoptions=[];
    selectParentAcc="";
    selnooflocations="1";
    selAccName="";
    selslaExpDate=null;
    selSlatype="";
    seldescription="";

    @wire(getParentAccounts) wired_getParentAccounts({data,error}){
        this.parentoptions=[];
        if(data){
        this.parentoptions=data.map((curritem)=>({
            label:curritem.Name,
            value:curritem.Id
        }));
        }
        else if(error){
            console.log("Error while getting Parent Accounts",error);
        }

    }

    @wire(getObjectInfo, {
        objectApiName:ACCOUNT_OBJECT
    })
     accountObjectInfo;

    @wire(getPicklistValues,
        {
            recordtypeId:"$accountObjectInfo.data.defaultRecordtypeId",
            fieldApiName:"SLA_TYPE"

    })
    slapicklist;

    handleChange(event)
    {
    let {name,value}=event.target;
    if(name ===  "parentacc"){
        this.selectParentAcc=value;
    } 
    if(name === "accname" )
    {
        this.selAccName=value;
    }
    if(name === "slaexpdt")
    {
    this.selslaExpDate=value;
    }
    if(name === "slatype")
    {
    this.selSlatype=value;
    }
    if(name === "nooflocations")
    {
    this.selnooflocations=value;
    }
    if(name === "description")
    {
    this.seldescription=value;
    }

    }
    saveRecord()
    {
   if(this.validateInput())
   {
    let inputfields={};
    inputfields[ACCOUNT_NAME.fieldApiName]=this.selAccName;
    inputfields[PARENT_ACCOUNT.fieldApiName]=this.selectParentAcc;
    inputfields[SLAEXPDATE.fieldApiName]=this.selslaExpDate;
    inputfields[SLA_TYPE.fieldApiName]=this.selSlatype;
    inputfields[NO_OF_LOCATIONS.fieldApiName]=this.selnooflocations;
    inputfields[DESCRIPTION.fieldApiName]=this.seldescription;

   let recordInput={
   apiName: ACCOUNT_OBJECT.objectApiName,
   fields:inputfields
    };

  createRecord(recordInput)
  .then(result=>{
  console.log("Record created successfuly!",result);
    })
    .catch(error=>{
        console.log("Error in Creation of Record",error);
    });

   }
   else
   {
    console.log("Inputs are not valid");
   }
    }
    validateInput(){
        let fields=Array.from(this.template.querySelectorAll(".validateme"));
        let isValid=fields.every((currItem)=>currItem.checkValidity());
        return isValid;
    }

}